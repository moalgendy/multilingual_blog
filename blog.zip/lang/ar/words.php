<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'dashboard' => 'لوحة التحكم',
    'settings' => 'الاعدادات',
    'translations'=>'الترجمات',
    'users'=>'المستخدمين',
    'not activated' => 'غير مفعل',
    'admin'=>'مدير الموقع',
    'writer'=>'كاتب',
    'add user'=>'اضافة مستخدم',
    'main category'=>'قسم رئيسي',
    'posts'=>'المقالات',
    'add post'=>'اضافة مقالة',
    'categories'=>'الأقسام',
    'add category'=>'إضافة قسم',
    'image'=>'الصورة',
    'status'=>'الحالة',
    'title'=>'العنوان',
    'content'=>'الوصف',
    'name'=>'الإسم',
    'email'=>'البريد الإلكتروني',
    'password'=>'رمز المرور',
    'home'=>'الصفحة الرئيسية',
    'user settings'=>'اعدادات المستخدم',
    'logout'=>'تسجيل الخروج',
    'close'=>'إلغاء',
    'delete'=>'حذف',
    'sure delete'=>'تأكيد الحذف',
    'favicon'=>'الايقونة',
    'logo'=>'اللوجو',
    'instagram'=>'الانستجرام',
    'facebook'=>'الفيس بوك',
    'phone'=>'الموبايل',
    'address'=>'العنوان',
    'tags'=>'التاجات',
    'smallDesc'=>'وصف صغير',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',

];