
<?php $__env->startSection('meta_description'); ?>
        <?php echo e(strip_tags($post->content)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_keywords'); ?>
        الكلمات الدلالية
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<?php echo e($post->title); ?> - <?php echo e($setting->title); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
 <!-- Breadcrumb Start -->
 <div class="container-fluid">
    <div class="container">
        <nav class="breadcrumb bg-transparent m-0 p-0">
            <a class="breadcrumb-item" href="<?php echo e(route('index')); ?>">Home</a>
            <span class="breadcrumb-item active">Category</span>
            
            
            <span class="breadcrumb-item active"><?php echo e($post->tags); ?></span>
        </nav>
    </div>
</div>
<!-- Breadcrumb End -->


<!-- News With Sidebar Start -->
<div class="container-fluid py-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- News Detail Start -->
                <div class="position-relative mb-3">
                    <img class="img-fluid w-100" src="<?php echo e(asset($post->image)); ?>" style="object-fit: cover;">
                    <div class="overlay position-relative bg-light">
                        <div class="mb-3">
                            <a href=""><?php echo e($post->category->title); ?></a>
                            <span class="px-1">/</span>
                            <span><?php echo e($post->created_at->format('D M,Y')); ?></span>
                        </div>
                        <div>
                            <h3 class="mb-3"><?php echo e($post->title); ?></h3>
                            
                            <p><?php echo $post->content; ?></p>
                        </div>
                    </div>
                </div>
                <!-- News Detail End -->

                

                
            </div>

            
        </div>
    </div>
</div>
</div>
<!-- News With Sidebar End -->


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/website/post.blade.php ENDPATH**/ ?>